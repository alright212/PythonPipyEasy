
def find_answer(a, b):
    # calculate (a+b)^2 using arithmetic operators
    return (a + b) ** 2
